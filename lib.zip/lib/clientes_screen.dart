import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ClientesScreen());
}

class ClientesScreen extends StatefulWidget {
  const ClientesScreen({super.key});

  @override
  State<ClientesScreen> createState() => _ClientesScreenState();
}

class _ClientesScreenState extends State<ClientesScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _dniController = TextEditingController();
  final TextEditingController _cargoController = TextEditingController();

  String? _areaSeleccionada;
  DateTime? _fechaIngreso;
  bool _activo = true;
  String? _idSeleccionado;

  final List<String> _areas = [
    'Cocina',
    'Atención',
    'Delivery',
    'Administración'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Clientes') ,
        backgroundColor: const Color.fromARGB(255, 0, 255, 0),
        centerTitle: true,
        foregroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                /// NOMBRE
                TextFormField(
                  controller: _nombreController,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(labelText: 'Nombre'),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Ingrese el nombre';
                    }
                    if (value.length < 3) {
                      return 'Mínimo 3 caracteres';
                    }
                    return null;
                  },
                ),

                /// DNI
                TextFormField(
                  controller: _dniController,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(8),
                  ],
                  decoration: const InputDecoration(labelText: 'DNI'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Ingrese DNI';
                    }
                    if (value.length != 8) {
                      return 'Debe tener 8 dígitos';
                    }
                    return null;
                  },
                ),

                /// ÁREA
                DropdownButtonFormField<String>(
                  value: _areaSeleccionada,
                  items: _areas
                      .map((e) =>
                          DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (v) => setState(() => _areaSeleccionada = v),
                  decoration: const InputDecoration(labelText: 'Área'),
                  validator: (v) =>
                      v == null ? 'Seleccione un área' : null,
                ),

                /// CARGO
                TextFormField(
                  controller: _cargoController,
                  decoration: const InputDecoration(labelText: 'Cargo'),
                  validator: (value) =>
                      value!.isEmpty ? 'Ingrese el cargo' : null,
                ),

                /// FECHA
                ListTile(
                  title: Text(_fechaIngreso == null
                      ? 'Seleccionar fecha'
                      : '${_fechaIngreso!.day}/${_fechaIngreso!.month}/${_fechaIngreso!.year}'),
                  trailing: const Icon(Icons.calendar_today),
                  onTap: () async {
                    final fecha = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime.now(),
                    );
                    if (fecha != null) {
                      setState(() => _fechaIngreso = fecha);
                    }
                  },
                ),

                /// BOTÓN
                ElevatedButton(
                  onPressed: () {
                    if (_fechaIngreso == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Seleccione fecha')));
                      return;
                    }

                    if (_formKey.currentState!.validate()) {
                      saveEmpleado();
                    }
                  },
                  child: const Text('Guardar'),
                ),

                /// LISTA
                StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('Empleados')
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) return Container();
                    final docs = snapshot.data!.docs;

                    return ListView.builder(
                      shrinkWrap: true,
                      itemCount: docs.length,
                      itemBuilder: (_, i) {
                        final d = docs[i];
                        return ListTile(
                          title: Text(d['nombreCompleto']),
                          subtitle: Text(d['dni']),
                        );
                      },
                    );
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> saveEmpleado() async {
    final data = {
      'nombreCompleto': _nombreController.text,
      'dni': _dniController.text,
      'area': _areaSeleccionada,
      'cargo': _cargoController.text,
      'fechaIngreso': _fechaIngreso,
      'activo': _activo,
    };

    if (_idSeleccionado == null) {
      await FirebaseFirestore.instance.collection('Empleados').add(data);
    } else {
      await FirebaseFirestore.instance
          .collection('Empleados')
          .doc(_idSeleccionado)
          .update(data);
    }

    limpiar();
  }

  void limpiar() {
    _nombreController.clear();
    _dniController.clear();
    _cargoController.clear();
    _areaSeleccionada = null;
    _fechaIngreso = null;
    _idSeleccionado = null;
    setState(() {});
  }
}