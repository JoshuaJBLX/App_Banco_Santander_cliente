import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ProductosScreen());
}

class ProductosScreen extends StatefulWidget {
  const ProductosScreen({super.key});

  @override
  State<ProductosScreen> createState() => _ProductosScreenState();
}

class _ProductosScreenState extends State<ProductosScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nombre = TextEditingController();
  final TextEditingController _precio = TextEditingController();

  String? _categoriaSeleccionada;
  String? _porcionSeleccionada;
  bool _disponible = true;

  final List<String> _categorias = [
    'Pollo a la brasa',
    'Parrillas',
    'Bebidas',
    'Guarniciones',
    'Postres',
  ];

  final List<String> _porciones = [
    '1/8',
    '1/4',
    '1/2',
    '1 Pollo',
    'Familiar',
    'Personal',
  ];

  String? _idSeleccionado;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Productos') ,
        backgroundColor: const Color.fromARGB(255, 0, 0, 255),
        centerTitle: true,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                /// NOMBRE
                TextFormField(
                  controller: _nombre,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: "Nombre del producto",
                    icon: Icon(Icons.label),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Ingrese el nombre del producto';
                    }
                    if (value.length < 3) {
                      return 'Mínimo 3 caracteres';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 10),

                /// PRECIO (VALIDACIÓN FUERTE)
                TextFormField(
                  controller: _precio,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                        RegExp(r'^\d*\.?\d{0,2}')),
                  ],
                  decoration: const InputDecoration(
                    labelText: "Precio",
                    icon: Icon(Icons.attach_money),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Ingrese el precio';
                    }

                    final numero = double.tryParse(value);

                    if (numero == null) {
                      return 'Ingrese un número válido';
                    }

                    if (numero <= 0) {
                      return 'Debe ser mayor a 0';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 10),

                /// PORCIÓN (LISTA)
                DropdownButtonFormField<String>(
                  value: _porcionSeleccionada,
                  items: _porciones.map((porcion) {
                    return DropdownMenuItem(
                      value: porcion,
                      child: Text(porcion),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _porcionSeleccionada = value;
                    });
                  },
                  decoration: const InputDecoration(
                    labelText: 'Porción',
                    icon: Icon(Icons.restaurant),
                  ),
                  validator: (value) =>
                      value == null ? 'Seleccione una porción' : null,
                ),

                const SizedBox(height: 10),

                /// CATEGORÍA
                DropdownButtonFormField<String>(
                  value: _categoriaSeleccionada,
                  items: _categorias.map((categoria) {
                    return DropdownMenuItem(
                      value: categoria,
                      child: Text(categoria),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _categoriaSeleccionada = value;
                    });
                  },
                  decoration: const InputDecoration(
                    labelText: 'Categoría',
                    icon: Icon(Icons.category),
                  ),
                  validator: (value) =>
                      value == null ? 'Seleccione una categoría' : null,
                ),

                const SizedBox(height: 10),

                /// DISPONIBLE
                SwitchListTile(
                  title: const Text('¿Disponible?'),
                  value: _disponible,
                  onChanged: (value) {
                    setState(() {
                      _disponible = value;
                    });
                  },
                  secondary: Icon(
                    _disponible ? Icons.check_circle : Icons.cancel,
                    color: _disponible ? Colors.green : Colors.red,
                  ),
                ),

                const SizedBox(height: 10),

                /// BOTÓN
                ElevatedButton.icon(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      if (_idSeleccionado == null) {
                        createProductos();
                      } else {
                        updateProductos(_idSeleccionado!);
                      }
                    }
                  },
                  icon: Icon(
                      _idSeleccionado == null ? Icons.add : Icons.save),
                  label: Text(_idSeleccionado == null
                      ? 'Agregar Producto'
                      : 'Actualizar Producto'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _idSeleccionado == null
                        ? Colors.green
                        : Colors.blue,
                  ),
                ),

                const SizedBox(height: 20),
                const Divider(),
                const SizedBox(height: 10),

                const Text(
                  'Lista de Productos',
                  style: TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 10),

                /// LISTA
                StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('Productos')
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      return const CircularProgressIndicator();
                    }

                    final docs = snapshot.data!.docs;

                    if (docs.isEmpty) {
                      return const Text('No hay productos registrados.');
                    }

                    return ListView.builder(
                      shrinkWrap: true,
                      physics:
                          const NeverScrollableScrollPhysics(),
                      itemCount: docs.length,
                      itemBuilder: (context, index) {
                        final producto = docs[index];

                        return Card(
                          child: ListTile(
                            title: Text(producto['nombre']),
                            subtitle: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                    'Precio: S/. ${producto['precio']}'),
                                Text(
                                    'Porción: ${producto['porcion']}'),
                                Text(
                                    'Categoría: ${producto['categoria']}'),
                                Text(producto['disponible']
                                    ? 'Disponible'
                                    : 'No disponible'),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit,
                                      color: Colors.blue),
                                  onPressed: () {
                                    setState(() {
                                      _idSeleccionado =
                                          producto.id;
                                      _nombre.text =
                                          producto['nombre'];
                                      _precio.text =
                                          producto['precio']
                                              .toString();
                                      _porcionSeleccionada =
                                          producto['porcion'];
                                      _categoriaSeleccionada =
                                          producto['categoria'];
                                      _disponible =
                                          producto['disponible'];
                                    });
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete,
                                      color: Colors.red),
                                  onPressed: () =>
                                      deleteProductos(
                                          producto.id),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// CRUD

  Future<void> createProductos() async {
    final datos = {
      'nombre': _nombre.text,
      'precio': double.parse(_precio.text),
      'porcion': _porcionSeleccionada,
      'categoria': _categoriaSeleccionada,
      'disponible': _disponible,
    };

    await FirebaseFirestore.instance
        .collection('Productos')
        .add(datos);

    limpiarFormulario();
  }

  Future<void> updateProductos(String id) async {
    final datos = {
      'nombre': _nombre.text,
      'precio': double.parse(_precio.text),
      'porcion': _porcionSeleccionada,
      'categoria': _categoriaSeleccionada,
      'disponible': _disponible,
    };

    await FirebaseFirestore.instance
        .collection('Productos')
        .doc(id)
        .update(datos);

    limpiarFormulario();
  }

  Future<void> deleteProductos(String id) async {
    await FirebaseFirestore.instance
        .collection('Productos')
        .doc(id)
        .delete();

    limpiarFormulario();
  }

  void limpiarFormulario() {
    _nombre.clear();
    _precio.clear();
    _categoriaSeleccionada = null;
    _porcionSeleccionada = null;
    _disponible = true;
    _idSeleccionado = null;
    setState(() {});
  }
}