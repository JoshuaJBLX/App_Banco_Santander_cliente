import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ProveedoresScreen extends StatefulWidget {
  const ProveedoresScreen({super.key});

  @override
  State<ProveedoresScreen> createState() => _ProveedoresScreenState();
}

class _ProveedoresScreenState extends State<ProveedoresScreen> {
  final _formKey = GlobalKey<FormState>();

  final _razon = TextEditingController();
  final _ruc = TextEditingController();
  final _direccion = TextEditingController();
  final _telefono = TextEditingController();
  final _email = TextEditingController();

  String? _categoria;
  String? _id;

  final categorias = ['Carnes', 'Verduras', 'Bebidas', 'Insumos'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Proveedores')),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [

                TextFormField(
                  controller: _razon,
                  decoration: const InputDecoration(labelText: 'Razón Social'),
                  validator: (v) =>
                      v!.length < 3 ? 'Mínimo 3 caracteres' : null,
                ),

                TextFormField(
                  controller: _ruc,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(11),
                  ],
                  decoration: const InputDecoration(labelText: 'RUC'),
                  validator: (v) =>
                      v!.length != 11 ? 'Debe tener 11 dígitos' : null,
                ),

                TextFormField(
                  controller: _telefono,
                  keyboardType: TextInputType.phone,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  decoration: const InputDecoration(labelText: 'Teléfono'),
                ),

                TextFormField(
                  controller: _email,
                  decoration: const InputDecoration(labelText: 'Email'),
                ),

                TextFormField(
                  controller: _direccion,
                  decoration: const InputDecoration(labelText: 'Dirección'),
                ),

                DropdownButtonFormField(
                  value: _categoria,
                  items: categorias
                      .map((e) =>
                          DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (v) => setState(() => _categoria = v),
                  decoration: const InputDecoration(labelText: 'Categoría'),
                ),

                /// BOTÓN
                ElevatedButton.icon(
                  icon: Icon(_id == null ? Icons.add : Icons.save),
                  label: Text(_id == null ? 'Agregar' : 'Actualizar'),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      guardar();
                    }
                  },
                ),

                const Divider(),

                /// LISTA
                StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('Proveedores')
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) return Container();

                    final docs = snapshot.data!.docs;

                    return ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: docs.length,
                      itemBuilder: (_, i) {
                        final d = docs[i];

                        return Card(
                          child: ListTile(
                            title: Text(d['razon_social']),
                            subtitle: Text('RUC: ${d['ruc']}'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit, color: Colors.blue),
                                  onPressed: () {
                                    setState(() {
                                      _id = d.id;
                                      _razon.text = d['razon_social'];
                                      _ruc.text = d['ruc'];
                                      _direccion.text = d['direccion'];
                                      _telefono.text = d['telefono'];
                                      _email.text = d['email'];
                                      _categoria = d['categoria'];
                                    });
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () =>
                                      FirebaseFirestore.instance
                                          .collection('Proveedores')
                                          .doc(d.id)
                                          .delete(),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> guardar() async {
    final data = {
      'razon_social': _razon.text,
      'ruc': _ruc.text,
      'direccion': _direccion.text,
      'telefono': _telefono.text,
      'email': _email.text,
      'categoria': _categoria,
    };

    if (_id == null) {
      await FirebaseFirestore.instance.collection('Proveedores').add(data);
    } else {
      await FirebaseFirestore.instance
          .collection('Proveedores')
          .doc(_id)
          .update(data);
    }

    limpiar();
  }

  void limpiar() {
    _razon.clear();
    _ruc.clear();
    _direccion.clear();
    _telefono.clear();
    _email.clear();
    _categoria = null;
    _id = null;
    setState(() {});
  }
}